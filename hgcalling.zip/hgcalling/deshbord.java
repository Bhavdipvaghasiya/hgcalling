package com.example.hgcalling;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.jitsi.meet.sdk.JitsiMeet;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;

import java.net.URL;

public class deshbord extends AppCompatActivity {
    EditText jcode;
    Button join,share;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deshbord);

        jcode=findViewById(R.id.joinbox);

        join=findViewById(R.id.joinbtn);
        share=findViewById(R.id.sharebtn);

        URL url;
        try {
            url=new URL("https://meet.jit.si");
            JitsiMeetConferenceOptions cop= new JitsiMeetConferenceOptions.Builder().setServerURL(url).setWelcomePageEnabled(false).build();
            JitsiMeet.setDefaultConferenceOptions(cop);
        }
        catch (Exception e)
        {
            e.fillInStackTrace();

        }

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JitsiMeetConferenceOptions jit = new JitsiMeetConferenceOptions.Builder().setRoom(jcode.getText().toString()).setWelcomePageEnabled(false).build();
                JitsiMeetActivity.launch(deshbord.this,jit);
            }
        });



    }
}