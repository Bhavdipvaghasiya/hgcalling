package com.example.hgcalling;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class signup extends AppCompatActivity {
    FirebaseFirestore database;
    FirebaseAuth auth;
    TextView email,pass,nam;
    Button lgn,crt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        email=findViewById(R.id.email);
        pass=findViewById(R.id.password);
        nam=findViewById(R.id.nm);

        database=FirebaseFirestore.getInstance();
        auth=FirebaseAuth.getInstance();

        lgn=findViewById(R.id.loginbtn);
        crt=findViewById(R.id.createbtn);

        lgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(signup.this,login.class));
            }
        });
        crt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name,eml,ps;
                eml=email.getText().toString();
                ps=pass.getText().toString();
                name=nam.getText().toString();


                user us = new user();
                us.setName(name);
                us.setEmail(eml);
                us.setPass(ps);



                auth.createUserWithEmailAndPassword(eml,ps).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            database.collection("users").document().set(us).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                startActivity(new Intent(signup.this,login.class));
                                }
                            });
                            Toast.makeText(signup.this, "Account is create", Toast.LENGTH_SHORT).show();

                        }
                        else
                        {
                           // startActivity(new Intent(signup.this,deshbord.class));
                            Toast.makeText(signup.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}